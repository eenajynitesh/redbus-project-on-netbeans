/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redbus;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;



 


public class redbus {
       public static void main(String[] args) {
        new login().setVisible(true);
       }
    
    Connection conn=null;
    
    public static Connection ConnectDB() {
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bus","root","");  
            
            JOptionPane.showMessageDialog(null, "Connection Done");
            return conn;
           
        }catch(HeadlessException | ClassNotFoundException | SQLException e){ 
            JOptionPane.showMessageDialog(null,e);
        
            return null;
        }  
        

    }
    
}
